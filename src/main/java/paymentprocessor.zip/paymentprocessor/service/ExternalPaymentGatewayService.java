package paymentprocessor.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import paymentprocessor.PaymentClient;
import paymentprocessor.enums.PaymentMethod;
import paymentprocessor.errorhandling.PaymentGatewayException;

public class ExternalPaymentGatewayService {

    PaymentClient paymentClient;
    Logger logger = LoggerFactory.getLogger(ExternalPaymentGatewayService.class);

    public void processPayment(String userId, Double amount, PaymentMethod method){
        logger.info("Making call to payment client for userId: {}, amount: {}, method: {}", userId, amount, method);

        try {
            paymentClient.makePayment(userId, amount, method);
        }
        catch (Exception e){
            logger.error("Error making payment call", e);
            e.printStackTrace();
            throw new PaymentGatewayException("Error making payment call");
        }

    }



}
